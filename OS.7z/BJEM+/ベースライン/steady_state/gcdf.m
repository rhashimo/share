
function gcdf = gcdf(omegabar, sigma)

 gcdf = normcdf(((log(omegabar)-sigma^2/2)/sigma),0,1);