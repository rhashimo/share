
function gammacdf = gammacdf(omegabar, sigma)

 gammacdf = gcdf(omegabar, sigma) ...
  +omegabar*(1-normcdf(((log(omegabar)+sigma^2/2)/sigma),0,1));