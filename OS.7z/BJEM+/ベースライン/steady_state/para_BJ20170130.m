%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   linear model 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all; tic;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Parameters and Technology for Goods Market
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
theta_c=7; % 11

CPI    =1;
%%CPI    =1.0015683218;

delta   =.028;%028
alpha   =.60; % 63
alpha_E =.02; % 003
alpha_FI=.02;
gama  =0.5*theta_c/(theta_c-1);

theta_wc=7; % 11

grkc_bar  =0.05; % meaningless para.. grkc_bar is determined by rkc_bar thr. back engineering.

%%2017/03/15 Okazaki Changed
%%beta    =.995;
beta = 0.998;
ksi     =.2;
%%vv      =.2; 
vv      =1.0;
%%gec      =.54; % 2015/2/23 governement expenditure, and others
gec = 0.24;
fic      =.0; % 2015/2/23 deleted export and import.
tau_c   = 0.00;% 2012/3/30 consumption tax for non-durable
tau_l   = 0.0;% 2012/3/30 labor income tax

%%2017/01/30 Okazaki Added
%%habit = 0.6;
habit = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Parameters and Technology for financial market
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rkc_bar  =(.05)+(1-delta);
zb0 = (1/beta)+((1+.56/100)^0.25-1);
defaultEC0 = 0.01/4; %0.05/4
defaultB0 = 0.01/4;
nECqkEC0 = 0.6; % 0.5
nBqk0 = 0.1; % 0.10 

%initial guess for endogeous variables
omegabarEC0 = 0.4982466814;
omegabarB0 = 0.4982466814;
gammaEC0 = 0.9796180919;
gammaB0 = 0.1;
muEC0 = 0.1171351567;
muB0 = 0.1171351567;
sigmaEC0 = 0.2712918724;
sigmaB0 = 0.2712918724;

x0FI = [omegabarEC0; omegabarB0; sigmaEC0; sigmaB0; muEC0; muB0; gammaEC0; gammaB0];

%%2017/01/30 Okazaki Changed
%%parametersI=[theta_c; CPI; delta; alpha; alpha_E; alpha_FI; gama; theta_wc; grkc_bar; beta; ksi; vv; gec; fic; tau_c; tau_l];
parametersI=[theta_c; CPI; delta; alpha; alpha_E; alpha_FI; gama; theta_wc; grkc_bar; beta; ksi; vv; gec; fic; tau_c; tau_l; habit];

parametersFI=[rkc_bar defaultEC0 defaultB0 zb0 nECqkEC0 nBqk0];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  calculating lc_bar and ld_bar
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
X0 = [.6];
OPTIONS=optimset('display','iter');
[X1, fval, exitflag]=fsolve('fvalue_M_JEM0330',X0,OPTIONS,parametersI);
l_bar=X1;

%obtaining other endogenous variables
var_ss0 = fvalue_M_JEM0330b(l_bar,parametersI);

%checking the consistenty with endogenous variables
check_ss0 = check_M_JEM0330b(parametersI,var_ss0);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  calculating steady state for financial variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
inputFI=[parametersI;var_ss0';parametersFI'];
XFI = fsolve('fvalue_M_JEM0330FI', x0FI,OPTIONS,inputFI)

inputC=[parametersI;parametersFI'];
X0C=[l_bar;XFI;grkc_bar];
[XC, fval, exitflag]=fsolve('fvalue_M_JEM0330C',X0C,OPTIONS,inputC);
[XC(10)]
parametersI(9)=XC(10);
XC=XC(1:end-1);
var_ss1 = fvalue_M_JEM0330b(XC(1),parametersI);

save data_for_dynare0330 parametersI parametersFI var_ss1 XC;

XC
parametersFI'