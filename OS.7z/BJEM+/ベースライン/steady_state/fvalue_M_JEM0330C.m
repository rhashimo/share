
function yyy = fvalue_M_JEM0330C(X0C, inputC);

X1=X0C(1:1);
X0=X0C(2:end);

%%2017/01/30 Okazaki Changed
% 2012/3/19 revised for government expenditure
%%parameters=inputC(1:16);
%%parametersFI=inputC(17:end);

parameters=inputC(1:17);
parametersFI=inputC(18:end);

lc_bar  = X1(1);

omegabarEC = X0(1);
omegabarB = X0(2);
sigmaEC = X0(3);
sigmaB = X0(4);
muEC = X0(5);
muB = X0(6);
gammaEC = X0(7);
gammaB = X0(8);
grkc_bar  =X0(9); % added on 2012/5/10

theta_c=parameters(1);
CPI    =parameters(2);
delta   =parameters(3);
alpha   =parameters(4);
alpha_E =parameters(5);
alpha_FI=parameters(6);
gama  =parameters(7);
theta_wc=parameters(8);
beta    =parameters(10);
ksi     =parameters(11);
vv      =parameters(12);
gec      =parameters(13);
fic      =parameters(14);
tau_c =parameters(15);
tau_l =parameters(16);

%%2017/01/30 OKazaki Added
habit = parameters(17);

rkc_bar=parametersFI(1); % added on 2012/5/10
defaultEC0=parametersFI(2);
defaultB0=parametersFI(3);
zeB0=parametersFI(4);
nECqkEC0=parametersFI(5);
nBqk0=parametersFI(6);

% ratio of production and fixed cost
Fc_Cg = theta_c/(theta_c-1)-1;

% expressing pc by cpi and px
pc_bar = CPI;

% expressing nominal marginal cost for durables and non-durables
phi_c=gama^-gama*(alpha*(1-gama))^(-alpha*(1-gama));
phi_c=phi_c*(alpha_E*(1-gama))^(-alpha_E*(1-gama));
phi_c=phi_c*(alpha_FI*(1-gama))^(-alpha_FI*(1-gama));
phi_c=phi_c*((1-alpha-alpha_E-alpha_FI)*(1-gama))^(-(1-alpha-alpha_E-alpha_FI)*(1-gama));

% expressing nominal wage in durables sector
wc_bar = (theta_c/(theta_c-1)*phi_c)^(1/(1-gama))*(alpha_E/alpha)^(alpha_E)*(alpha_FI/alpha)^(alpha_FI);
wc_bar = wc_bar*lc_bar^(alpha_E+alpha_FI)*grkc_bar^(1-alpha-alpha_E-alpha_FI)/pc_bar;
wc_bar = wc_bar^(-1/(alpha+alpha_E+alpha_FI));
w_FIc=alpha_FI*wc_bar*lc_bar/alpha;
w_ec=alpha_E*wc_bar*lc_bar/alpha;
mcc_bar=phi_c*pc_bar^gama*(w_ec^alpha_E*w_FIc^alpha_FI*wc_bar^alpha*grkc_bar^(1-alpha-alpha_E-alpha_FI))^(1-gama);

%%2017/01/30 Okazaki Changed
%%c_bar=(1-tau_l)/(1+tau_c)*(theta_wc-1)/theta_wc/pc_bar*wc_bar/ksi/(lc_bar)^vv;
c_bar=(1-tau_l)/(1+tau_c)*(theta_wc-1)/theta_wc/pc_bar*wc_bar/ksi/(lc_bar)^vv*(1-beta*habit)/(1-habit);

kc_bar=(1-alpha-alpha_E-alpha_FI)*wc_bar*lc_bar/grkc_bar/alpha;

Q_bar=1; % revised on 2012/5/10
rec0=(grkc_bar/CPI+Q_bar*(1-delta))/Q_bar;
rec00=rkc_bar-rec0; % 2012/5/10

% 2012/3/19 added government expenditure (1+0.2)*
lss01=-wc_bar*lc_bar/alpha/mcc_bar/(1+Fc_Cg)/(1-gama)...
+(1+gec)*c_bar+(1+fic)*delta*(1-alpha-alpha_E-alpha_FI)/alpha*(wc_bar*lc_bar/grkc_bar)...
+gama*wc_bar*lc_bar/alpha/pc_bar/(1-gama)...
+(muEC*gcdf(omegabarEC, sigmaEC)*rec0*kc_bar*Q_bar...
+muB*gcdf(omegabarB, sigmaB)*((gammacdf(omegabarEC, sigmaEC)-muEC*gcdf(omegabarEC, sigmaEC))*rec0*kc_bar*Q_bar)...
+(1-gammaEC)*(1-gammacdf(omegabarEC, sigmaEC))*rec0*kc_bar*Q_bar...
+(1-gammaB)*((1-gammacdf(omegabarB, sigmaB))*((gammacdf(omegabarEC, sigmaEC)-muEC*gcdf(omegabarEC, sigmaEC))*rec0*kc_bar*Q_bar)))/pc_bar;

lss1=lss01*10;

%financial variables
Q_bar=1; % revised on 2012/5/10
nECqkEC = nECqkEC0 - gammaEC*(1-gammacdf(omegabarEC, sigmaEC))*rec0- alpha_E/(1-alpha-alpha_E-alpha_FI)*grkc_bar;
nBqk = nBqk0 - gammaB*((1-gammacdf(omegabarB, sigmaB))*((gammacdf(omegabarEC, sigmaEC)-muEC*gcdf(omegabarEC, sigmaEC))*rec0))-alpha_E/(1-alpha-alpha_E-alpha_FI)*grkc_bar;;
defaultEC = defaultEC0 - normcdf(((log(omegabarEC)+sigmaEC^2/2)/sigmaEC),0,1);
defaultB = defaultB0 - normcdf(((log(omegabarB)+sigmaB^2/2)/sigmaB),0,1);
rer = (gammacdf(omegabarB, sigmaB)-muB*gcdf(omegabarB, sigmaB))*((gammacdf(omegabarEC, sigmaEC)-muEC*gcdf(omegabarEC, sigmaEC))*rec0)-1/beta*(1-nBqk0-nECqkEC0);
    optimEC = (1-gammacdf(omegabarB, sigmaB))*(...
     gammacdf(omegabarEC, sigmaEC)-muEC*gcdf(omegabarEC, sigmaEC))*rec0 +...
     d_gammacdf(omegabarB, sigmaB)/(...
     d_gammacdf(omegabarB, sigmaB)-muB*d_gcdf(omegabarB, sigmaB))*((...
     gammacdf(omegabarB, sigmaB)-muB*gcdf(omegabarB, sigmaB))*(...
     gammacdf(omegabarEC, sigmaEC)-muEC*gcdf(omegabarEC, sigmaEC))*rec0) -...
     d_gammacdf(omegabarB, sigmaB)/(d_gammacdf(omegabarB, sigmaB)-muB*d_gcdf(omegabarB, sigmaB))/beta...
     +(1-gammacdf(omegabarB, sigmaB))*(d_gammacdf(omegabarEC, sigmaEC)-muEC*d_gcdf(omegabarEC, sigmaEC))*...
     (1-gammacdf(omegabarEC, sigmaEC))/d_gammacdf(omegabarEC, sigmaEC)*rec0...
     +d_gammacdf(omegabarB, sigmaB)*(gammacdf(omegabarB, sigmaB)-muB*gcdf(omegabarB, sigmaB))*...
     (d_gammacdf(omegabarEC, sigmaEC)-muEC*d_gcdf(omegabarEC, sigmaEC))*(1-gammacdf(omegabarEC, sigmaEC))*rec0/...
     (d_gammacdf(omegabarB, sigmaB)-muB*d_gcdf(omegabarB, sigmaB))/d_gammacdf(omegabarEC, sigmaEC);

zeb =-omegabarB*((gammacdf(omegabarEC, sigmaEC)-muEC*gcdf(omegabarEC, sigmaEC))*rec0)+zeB0*(1-nECqkEC0-nBqk0);

constraint1 = (1-gammacdf(omegabarEC, sigmaEC)) - nECqkEC0;

yyy   =10000*[lss1; nECqkEC; nBqk; defaultEC; defaultB; rer; optimEC; zeb; constraint1; rec00];

