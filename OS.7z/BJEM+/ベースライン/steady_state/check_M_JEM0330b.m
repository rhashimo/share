
function check_ss= check_M_JEM0330b(parameters,var_ss);

lc_bar=var_ss(1); 
c_bar=var_ss(2);
c_c_bar=var_ss(3); 
kc_bar=var_ss(4);
mcc_bar=var_ss(5);
pc_bar=var_ss(6);
wc_bar=var_ss(7);
w_FIc=var_ss(8);
w_ec=var_ss(9);
cg_bar=var_ss(10);

theta_c=parameters(1);
CPI    =parameters(2);
delta   =parameters(3);
alpha   =parameters(4);
alpha_E =parameters(5);
alpha_FI=parameters(6);
gama  =parameters(7);
theta_wc=parameters(8);
grkc_bar  =parameters(9);
beta    =parameters(10);
ksi     =parameters(11);
vv      =parameters(12);
gec      =parameters(13);
fic      =parameters(14);
tau_c =parameters(15);
tau_l =parameters(16);

%%2017/01/30 Okazaki Added
habit =parameters(17);

% 2012/3/19 added government expenditure
c1 = cg_bar - c_c_bar-(1+gec)*c_bar-(1+fic)*delta*kc_bar;

%%2017/01/30 Okazaki Changed
%%c4 = ksi*(lc_bar)^vv/wc_bar-(theta_wc-1)/theta_wc/c_bar/pc_bar*(1-tau_l)/(1+tau_c);
c4 = ksi*(lc_bar)^vv/wc_bar-(theta_wc-1)/theta_wc/c_bar/pc_bar*(1-tau_l)/(1+tau_c)*(1-beta*habit)/(1-habit);

c7 = pc_bar - theta_c/(theta_c-1)*mcc_bar;
zz = [c1 c4 c7];
tt = zz*zz';

ddd =(var_ss <0);
for jj=1:size(var_ss,2);
if ddd(jj) > 0.0,
    disp('out1');
    pause;
else
    disp('');
    ss1=0;
end
end

if tt >= 0.000000000000001,
    disp('out2');
    pause;
else
    disp('');
    ss2=0;
end

check_ss=[ss1 ss2];
