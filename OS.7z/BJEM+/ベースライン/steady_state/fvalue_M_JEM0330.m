
function l_ss= fvalue_M_JEM0330(X0, parameters);

lc_bar  = X0(1);

theta_c=parameters(1);
CPI    =parameters(2);
delta   =parameters(3);
alpha   =parameters(4);
alpha_E =parameters(5);
alpha_FI=parameters(6);
gama  =parameters(7);
theta_wc=parameters(8);
grkc_bar  =parameters(9);
beta    =parameters(10);
ksi     =parameters(11);
vv      =parameters(12);
gec      =parameters(13);
fic      =parameters(14);
tau_c =parameters(15);
tau_l =parameters(16);

%%2017/01/30 Okazaki Added
habit =parameters(17);

% ratio of production and fixed cost
Fc_Cg = theta_c/(theta_c-1)-1;

% expressing pc by cpi and px
pc_bar = CPI;

% expressing nominal marginal cost for durables and non-durables
phi_c=gama^-gama*(alpha*(1-gama))^(-alpha*(1-gama));
phi_c=phi_c*(alpha_E*(1-gama))^(-alpha_E*(1-gama));
phi_c=phi_c*(alpha_FI*(1-gama))^(-alpha_FI*(1-gama));
phi_c=phi_c*((1-alpha-alpha_E-alpha_FI)*(1-gama))^(-(1-alpha-alpha_E-alpha_FI)*(1-gama));

% expressing nominal wage in durables sector
wc_bar = (theta_c/(theta_c-1)*phi_c)^(1/(1-gama))*(alpha_E/alpha)^(alpha_E)*(alpha_FI/alpha)^(alpha_FI);
wc_bar = wc_bar*lc_bar^(alpha_E+alpha_FI)*grkc_bar^(1-alpha-alpha_E-alpha_FI)/pc_bar;
wc_bar = wc_bar^(-1/(alpha+alpha_E+alpha_FI));
w_FIc=alpha_FI*wc_bar*lc_bar/alpha;
w_ec=alpha_E*wc_bar*lc_bar/alpha;
mcc_bar=phi_c*pc_bar^gama*(w_ec^alpha_E*w_FIc^alpha_FI*wc_bar^alpha*grkc_bar^(1-alpha-alpha_E-alpha_FI))^(1-gama);

%%2017/01/30 Okazaki Changed
%%c_bar=(1-tau_l)/(1+tau_c)*(theta_wc-1)/theta_wc/pc_bar*wc_bar/ksi/(lc_bar)^vv;
c_bar=(1-tau_l)/(1+tau_c)*(theta_wc-1)/theta_wc/pc_bar*wc_bar/ksi/(lc_bar)^vv*(1-beta*habit)/(1-habit);

lss01=-wc_bar*lc_bar/alpha/mcc_bar/(1+Fc_Cg)/(1-gama)+(1+gec)*c_bar+(1+fic)*delta*(1-alpha-alpha_E-alpha_FI)/alpha*(wc_bar*lc_bar/grkc_bar)+gama*wc_bar*lc_bar/alpha/pc_bar/(1-gama);
lss1=lss01*10;
l_ss   =[lss1];
