%--------------------------------------------------------------------------
                            % Steady-state results
%--------------------------------------------------------------------------
for shock_index = 1:num_shocks;
    shock_name = char(shock_list(shock_index));

    % copy template file
    filetemppath = fullfile(basedir, '12_FileTemplate', 'estIRF.xlsx');
    outputpath = strcat(workdir,'/output/estIRF_',modelType,'_',shock_name,'.xlsx');
    copyfile(filetemppath, outputpath);

    num_vars = length(variable_list);
    irf_length = 121;
    initial_array = zeros(num_vars, 1);
    median_array = zeros(irf_length, num_vars);
    high_array = zeros(irf_length, num_vars);
    low_array = zeros(irf_length, num_vars);

    % initialize IRF generation
    initial_condition_states = repmat(oo_.dr.ys,1,M_.maximum_lag);

    for index = 1:num_vars
        initial_array(index) = initial_condition_states(strmatch(variable_list(1,index), ...
                                                                    M_.endo_names,'exact'), :);
    end

    writecell(variable_list, outputpath, 'Sheet', 'SS', 'Range', 'A1');
    writematrix(initial_array.', outputpath, 'Sheet', 'SS', 'Range', 'A2');

    %--------------------------------------------------------------------------
                                % Baysean IRF results
    %--------------------------------------------------------------------------

    for index = 1:num_vars
        median_array(:,index) = getfield(oo_.PosteriorIRF.dsge.Median, ...
                                        string(strcat(variable_list(1,index),'_',shock_name)));
        high_array(:,index) = getfield(oo_.PosteriorIRF.dsge.HPDinf, ...
                                        string(strcat(variable_list(1,index),'_',shock_name)));
        low_array(:,index) = getfield(oo_.PosteriorIRF.dsge.HPDsup, ...
                                        string(strcat(variable_list(1,index),'_',shock_name)));
    end

    writecell(variable_list, outputpath, 'Sheet', 'Median', 'Range', 'A1');
    writematrix(median_array, outputpath, 'Sheet', 'Median', 'Range', 'A2');

    writecell(variable_list, outputpath, 'Sheet', 'p10', 'Range', 'A1');
    writematrix(high_array, outputpath, 'Sheet', 'p10', 'Range', 'A2');

    writecell(variable_list, outputpath, 'Sheet', 'p90', 'Range', 'A1');
    writematrix(low_array, outputpath, 'Sheet', 'p90', 'Range', 'A2');


    Sheet_names = {'Median','p10','p90'};
    variable_list_Q = repmat(variable_list, 1, 3);
    key_list_Q = repelem(Sheet_names, num_vars);
    writecell(variable_list_Q, outputpath, 'Sheet', 'Qlv', 'Range', 'C2');
    writecell(key_list_Q, outputpath, 'Sheet', 'Qlv', 'Range', 'C1');
end;