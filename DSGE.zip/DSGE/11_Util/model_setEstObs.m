%-------------------------------------------------------------------------------------------------%
% File Name --- model_estim_obs.m
%
% README (written by Ryuichiro Hashimoto, Oct. 2021)
% This code section loads a matrix for observable and assign variables.
%
% Update logs:
%   - 9/17/2021 Retrieved from original (see Prev Directory for the original)
%               fdr added (nobs=134, fdr starts from 1984Q1)
%   - 9/28/2021 Recreated est_data file
%               edr added (nobs=144, from 1984Q2 to 2019Q4)
%-------------------------------------------------------------------------------------------------%




datapath    = strcat(pwd,'/../13_Data/est_data.xlsx');
est_data    = readmatrix(datapath, 'Sheet', 'Est_Input');

l_pi_c      = est_data(:, 1);
l_IC        = est_data(:, 2);
l_pi_d      = est_data(:, 3);
l_Output    = est_data(:, 4);
l_HC        = est_data(:, 5);
l_WC        = est_data(:, 6);
l_NSR       = est_data(:, 7);
l_NB        = est_data(:, 8);
l_NEC	    = est_data(:, 9);
l_Solow	    = est_data(:,10);
