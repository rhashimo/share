%-------------------------------------------------------------------------------------------------%
                                        % Set Initial States
%-------------------------------------------------------------------------------------------------%
for ix = 1:nMLITscenario

    % set output file name
    outfilepath = strcat(workdir,'/output/MLIT_',modelType,'_S',num2str(ix),'.xlsx');
    fdrfilepath = strcat(basedir,'/13_Data/MLIT_fdr_S',num2str(ix),'.csv');
    fdrpfilepath = strcat(basedir,'/13_Data/MLIT_fdr_p_S',num2str(ix),'.csv');

    % copy template file
    copyfile(strcat(basedir,'/12_FileTemplate/Frcst.xlsx'), outfilepath);

    % load fdr_series
    period_array = zeros((yearTo - yearFrom + 1)*4, 2);
    period_array(:,1) = repelem([yearFrom:yearTo], 4);
    period_array(:,2) = repmat([1 2 3 4], 1, yearTo - yearFrom + 1);
    year_array = unique(period_array(:,1));

    fdr_series = readmatrix(fdrfilepath);
    fdrp_series = readmatrix(fdrpfilepath);
    irf_length = size(fdr_series,1);
    num_series = size(fdr_series,2);
    num_vars = length(variable_list);
    output_array = zeros(irf_length, num_series, num_vars);
    initial_array = zeros(num_vars, 1);

    % initialize IRF generation
    initial_condition_states = repmat(oo_.dr.ys,1,M_.maximum_lag);
    shock_matrix = zeros(irf_length,M_.exo_nbr);

    for index = 1:num_vars
        initial_array(index) = initial_condition_states(strmatch(variable_list(index), ...
                                                                    M_.endo_names,'exact'), :);
    end

    %-------------------------------------------------------------------------------------------------%
                                            % Looping over fdr_series
    %-------------------------------------------------------------------------------------------------%
    h = waitbar(0,'Looping over fdr series...');
    for series = 1:num_series
        waitbar(series/num_series)
        shock_matrix(:,strmatch('nu_fdr',M_.exo_names,'exact')) = fdr_series(:,series);
        shock_matrix(:,strmatch('nu_fdr_p',M_.exo_names,'exact')) = fdrp_series(:,series);
        y2 = simult_(M_,options_,initial_condition_states,oo_.dr,shock_matrix,1);
        y_IRF = y2(:,M_.maximum_lag+1:end)-repmat(oo_.dr.ys,1,irf_length);
        for index = 1:num_vars
            output_array(:, series+2, index) = y_IRF(strmatch(char(variable_list(index)), ...
                                                                M_.endo_names,'exact'), :).';
        end
    end
    close(h)

    for index = 1:num_vars
        writematrix(output_array(:, 3:49, index), outfilepath, 'Sheet', char(variable_list(index)), ...
                        'Range', 'A1');
    end

    %-------------------------------------------------------------------------------------------------%
                                            % Calculate Mean, p10, and p90
    %-------------------------------------------------------------------------------------------------%
    median_array = squeeze(median(output_array, 2));
    p10_array = squeeze(prctile(output_array, 10, 2));
    p90_array = squeeze(prctile(output_array, 90, 2));

    %-------------------------------------------------------------------------------------------------%
                                            % Saving output
    %-------------------------------------------------------------------------------------------------%
    % write variable name and period
    Sheet_names = {'Median','p10','p90'};
    writecell(variable_list, outfilepath, 'Sheet', 'SS', 'Range', 'A1');
    for index = 1:length(Sheet_names)
        writecell({'Year','Q'}, outfilepath, ...
                        'Sheet', char(Sheet_names(index)), 'Range', 'A1');
        writecell(variable_list, outfilepath, ...
                        'Sheet', char(Sheet_names(index)), 'Range', 'C1');
        writematrix(period_array, outfilepath, ...
                        'Sheet', char(Sheet_names(index)), 'Range', 'A2');
    end

    writematrix(period_array, outfilepath, 'Sheet', 'Qlv', 'Range', 'A3');
    writematrix(year_array, outfilepath, 'Sheet', 'Ylv', 'Range', 'A3');

    % write results
    writematrix(initial_array.', outfilepath, 'Sheet', 'SS', 'Range', 'A2');
    writematrix(median_array, outfilepath, 'Sheet', 'Median', 'Range', 'C2');
    writematrix(p10_array, outfilepath, 'Sheet', 'p10', 'Range', 'C2');
    writematrix(p90_array, outfilepath, 'Sheet', 'p90', 'Range', 'C2');

    % write quarter sheet
    variable_list_Q = repmat(variable_list, 1, 3);
    key_list_Q = repelem(Sheet_names, num_vars);
    writecell(variable_list_Q, outfilepath, 'Sheet', 'Qlv', 'Range', 'C2');
    writecell(key_list_Q, outfilepath, 'Sheet', 'Qlv', 'Range', 'C1');

end