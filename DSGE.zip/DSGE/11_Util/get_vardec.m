colsize = 98;
numshock = 21;
vardec = oo_.conditional_variance_decomposition;
vardec_result = zeros(colsize*41, numshock);

vlist = repmat(M_.endo_names(1:colsize), 41, 1);

for irf = 1:41
    for shock = 1:numshock
        vardec_result((irf-1)*colsize+1:irf*colsize,shock) = vardec(:,irf,shock);
    end
end