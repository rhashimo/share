object_list = {'oo_.posterior_mean','oo_.posterior_hpdinf','oo_.posterior_hpdsup'};
num_objs = length(object_list);

for index = 1:num_objs
    fileID = fopen(string(strcat(workdir, '/output/results/', object_list(1,index),'.json')),'w');
    fprintf(fileID, jsonencode(eval(string(object_list(1,index)))));
    fclose(fileID);

end

outfilepath = string(strcat(workdir, '/output/results/SS.xlsx'));
writecell(eval('M_.endo_names'), outfilepath, 'Sheet', 1, 'Range', 'A1');
writematrix(eval('oo_.steady_state'), outfilepath, 'Sheet', 1, 'Range', 'B1');