
function d_gcdf = d_gcdf(omegabar, sigma)
 
 d_gcdf = 1/sigma/omegabar*(1/sqrt(2*3.14159265358979))*exp(...
   -.5*((log(omegabar)-sigma^2/2)/sigma)^2);