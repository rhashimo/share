function objective = fvalue_M_JEM1002FI(X0, inputFI);

%%2017/01/30 Okazaki Changed
%%parameters=inputFI(1:16,:);
%%var_ss=inputFI(17:17+9,:);
%%parametersFI=inputFI(17+10:end,:);

parameters=inputFI(1:17,:);
var_ss=inputFI(18:18+9,:);
parametersFI=inputFI(18+10:end,:);


lc_bar=var_ss(1); 
c_bar=var_ss(2);
c_c_bar=var_ss(3); 
kc_bar=var_ss(4);
mcc_bar=var_ss(5);
pc_bar=var_ss(6);
wc_bar=var_ss(7);
w_FIc=var_ss(8);
w_ec=var_ss(9);
cg_bar=var_ss(10);

theta_c=parameters(1);
CPI    =parameters(2);
delta   =parameters(3);
alpha   =parameters(4);
alpha_E =parameters(5);
alpha_FI=parameters(6);
gama  =parameters(7);
theta_wc=parameters(8);
grkc_bar  =parameters(9);
beta    =parameters(10);
ksi     =parameters(11);
vv      =parameters(12);
gec      =parameters(13);
fic      =parameters(14);
tau_c =parameters(15);
tau_l =parameters(16);

%%2017/01/30 Okazaki Added
habit =parameters(17);

rec0=parametersFI(1);
defaultEC0=parametersFI(2);
defaultB0=parametersFI(3);
zeB0=parametersFI(4);
nECqkEC0=parametersFI(5);
nBqk0=parametersFI(6);

omegabarEC = X0(1);
omegabarB = X0(2);
sigmaEC = X0(3);
sigmaB = X0(4);
muEC = X0(5);
muB = X0(6);
gammaEC = X0(7);
gammaB = X0(8);

nECqkEC = nECqkEC0 - gammaEC*(1-gammacdf(omegabarEC, sigmaEC))*rec0- alpha_E/(1-alpha-alpha_E-alpha_FI)*grkc_bar;

nBqk = nBqk0 - gammaB*((1-gammacdf(omegabarB, sigmaB))*((gammacdf(omegabarEC, sigmaEC)-muEC*gcdf(omegabarEC, sigmaEC))*rec0))+alpha_E/(1-alpha-alpha_E-alpha_FI)*grkc_bar;;

defaultEC = defaultEC0 - normcdf(((log(omegabarEC)+sigmaEC^2/2)/sigmaEC),0,1);

defaultB = defaultB0 - normcdf(((log(omegabarB)+sigmaB^2/2)/sigmaB),0,1);

rer = (gammacdf(omegabarB, sigmaB)-muB*gcdf(omegabarB, sigmaB))*((gammacdf(omegabarEC, sigmaEC)-muEC*gcdf(omegabarEC, sigmaEC))*rec0)-1/beta*(1-nBqk0-nECqkEC0);
    optimEC = (1-gammacdf(omegabarB, sigmaB))*(...
     gammacdf(omegabarEC, sigmaEC)-muEC*gcdf(omegabarEC, sigmaEC))*rec0 +...
     d_gammacdf(omegabarB, sigmaB)/(...
     d_gammacdf(omegabarB, sigmaB)-muB*d_gcdf(omegabarB, sigmaB))*((...
     gammacdf(omegabarB, sigmaB)-muB*gcdf(omegabarB, sigmaB))*(...
     gammacdf(omegabarEC, sigmaEC)-muEC*gcdf(omegabarEC, sigmaEC))*rec0) -...
     d_gammacdf(omegabarB, sigmaB)/(d_gammacdf(omegabarB, sigmaB)-muB*d_gcdf(omegabarB, sigmaB))/beta...
     +(1-gammacdf(omegabarB, sigmaB))*(d_gammacdf(omegabarEC, sigmaEC)-muEC*d_gcdf(omegabarEC, sigmaEC))*...
     (1-gammacdf(omegabarEC, sigmaEC))/d_gammacdf(omegabarEC, sigmaEC)*rec0...
     +d_gammacdf(omegabarB, sigmaB)*(gammacdf(omegabarB, sigmaB)-muB*gcdf(omegabarB, sigmaB))*...
     (d_gammacdf(omegabarEC, sigmaEC)-muEC*d_gcdf(omegabarEC, sigmaEC))*(1-gammacdf(omegabarEC, sigmaEC))*rec0/...
     (d_gammacdf(omegabarB, sigmaB)-muB*d_gcdf(omegabarB, sigmaB))/d_gammacdf(omegabarEC, sigmaEC);

zeb =-omegabarB*((gammacdf(omegabarEC, sigmaEC)-muEC*gcdf(omegabarEC, sigmaEC))*rec0)+zeB0*(1-nECqkEC0-nBqk0);

constraint1 = (1-gammacdf(omegabarEC, sigmaEC)) - nECqkEC0;
objective = [nECqkEC; nBqk; defaultEC; defaultB; rer; optimEC; zeb; constraint1];

